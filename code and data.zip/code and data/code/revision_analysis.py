import os
import math
import random

import numpy as np
import pandas as pd

from aeb_trace_experiments import build_benchmark_cache, generate_aeb_graph, run_qaco


OUTDIR = "aeb_experiment_package"
DATADIR = os.path.join(OUTDIR, "data")
SUPPDIR = os.path.join(OUTDIR, "supplementary")


def bootstrap_ci(values, n_boot=5000, seed=20260704):
    values = np.asarray(values, dtype=float)
    rng = np.random.default_rng(seed)
    if len(values) == 0:
        return float("nan"), float("nan")
    idx = rng.integers(0, len(values), size=(n_boot, len(values)))
    means = values[idx].mean(axis=1)
    return float(np.quantile(means, 0.025)), float(np.quantile(means, 0.975))


def paired_summary(df):
    metrics = [
        ("reference_coverage", "qaco_minus_baseline"),
        ("compactness", "qaco_minus_baseline"),
        ("runtime_ms", "qaco_minus_baseline"),
        ("success", "qaco_minus_baseline"),
    ]
    baselines = ["ACO", "GA", "Tabu"]
    rows = []
    for baseline in baselines:
        q = df[df["method"] == "QACO"].set_index(["seed", "case", "mode"])
        b = df[df["method"] == baseline].set_index(["seed", "case", "mode"])
        joined = q.join(b, lsuffix="_qaco", rsuffix="_baseline", how="inner")
        for metric, direction in metrics:
            diff = joined[f"{metric}_qaco"] - joined[f"{metric}_baseline"]
            lo, hi = bootstrap_ci(diff.to_numpy())
            rows.append(
                {
                    "comparison": f"QACO vs {baseline}",
                    "metric": metric,
                    "n_pairs": len(diff),
                    "mean_difference": diff.mean(),
                    "median_difference": diff.median(),
                    "ci95_low": lo,
                    "ci95_high": hi,
                    "direction": direction,
                }
            )
    return pd.DataFrame(rows)


def run_parameter_sensitivity(n_seeds=12):
    graph = generate_aeb_graph("AEB-S4", 34, 5, seed=4)
    cache = build_benchmark_cache({"AEB-S4": graph})["AEB-S4"]
    compact_ref = cache["ref_add"]
    threshold = cache["thr_add"]
    exact_value = cache["exact_add"]

    settings = [
        ("alpha", 0.5, {"alpha": 0.5}),
        ("alpha", 1.0, {"alpha": 1.0}),
        ("alpha", 1.5, {"alpha": 1.5}),
        ("beta", 1.0, {"beta": 1.0}),
        ("beta", 2.0, {"beta": 2.0}),
        ("beta", 3.0, {"beta": 3.0}),
        ("rho", 0.05, {"evap": 0.05}),
        ("rho", 0.15, {"evap": 0.15}),
        ("rho", 0.30, {"evap": 0.30}),
    ]

    rows = []
    for parameter, value, overrides in settings:
        for seed in range(1, n_seeds + 1):
            result = run_qaco(graph, "add", compact_ref, threshold, 420, seed, overrides=overrides)
            rows.append({"parameter": parameter, "value": value, "seed": seed,
                         "case": "AEB-S4", "mode": "add", "exact_ratio": result["returned_value"] / exact_value,
                         **result})
    raw = pd.DataFrame(rows)
    summary = raw.groupby(["parameter", "value"], sort=False).agg(
        exact_ratio_mean=("exact_ratio", "mean"),
        exact_ratio_std=("exact_ratio", "std"),
        reference_coverage_mean=("reference_coverage", "mean"),
        reference_coverage_std=("reference_coverage", "std"),
        compactness_mean=("compactness", "mean"),
        compactness_std=("compactness", "std"),
        success_mean=("success", "mean"),
        success_std=("success", "std"),
        runtime_ms_mean=("runtime_ms", "mean"),
        runtime_ms_std=("runtime_ms", "std"),
        accepted_paths_mean=("accepted_paths", "mean"),
        evals_mean=("evals", "mean"),
    ).reset_index()
    return raw, summary


def main():
    os.makedirs(SUPPDIR, exist_ok=True)
    run_results = pd.read_csv(os.path.join(DATADIR, "run_results.csv"))
    paired = paired_summary(run_results)
    paired.to_csv(os.path.join(SUPPDIR, "qaco_paired_comparisons.csv"), index=False)

    raw, summary = run_parameter_sensitivity()
    raw.to_csv(os.path.join(SUPPDIR, "qaco_parameter_sensitivity_runs.csv"), index=False)
    summary.to_csv(os.path.join(SUPPDIR, "qaco_parameter_sensitivity_summary.csv"), index=False)

    print("Wrote supplementary revision analyses to", SUPPDIR)


if __name__ == "__main__":
    main()
