"""Verify saved ACO/QACO/Tabu values against the experiment code.

GA was not fully seed-controlled in the historical source; wall-clock times are
hardware-dependent. Neither is included in the exact-value comparison.
"""
from __future__ import annotations

import sys
import types
from pathlib import Path

import pandas as pd

try:
    import matplotlib.pyplot  # noqa: F401
except ModuleNotFoundError:
    sys.modules["matplotlib"] = types.ModuleType("matplotlib")
    sys.modules["matplotlib.pyplot"] = types.ModuleType("matplotlib.pyplot")

import aeb_trace_experiments as exp

ROOT = Path(__file__).resolve().parents[1]
archive = pd.read_csv(ROOT / "data" / "run_results_with_ratios.csv")
reference = pd.read_csv(ROOT / "data" / "exact_reference_values.csv").set_index("case")
specs = [("AEB-S1", 12, 2, 1, 60), ("AEB-S2", 18, 3, 2, 140),
         ("AEB-S3", 26, 4, 3, 260), ("AEB-S4", 34, 5, 4, 420)]
methods = {"ACO": exp.run_aco, "QACO": exp.run_qaco, "Tabu": exp.run_tabu}
fields = ["returned_value", "reference_coverage", "reference_gap",
          "compactness", "success", "accepted_paths", "evals"]
max_diff = 0.0
count = 0
for case, width, outdeg, graph_seed, budget in specs:
    graph = exp.generate_aeb_graph(case, width, outdeg, seed=graph_seed)
    cache = exp.build_benchmark_cache({case: graph})[case]
    for mode in ("mult", "add"):
        max_diff = max(max_diff,
                       abs(cache[f"exact_{mode}"] - reference.loc[case, f"exact_{mode}"]),
                       abs(cache[f"ref_{mode}"] - reference.loc[case, f"compact_ref_{mode}_top12"]))
        for seed in range(1, 13):
            for method, fn in methods.items():
                result = fn(graph, mode, cache[f"ref_{mode}"], cache[f"thr_{mode}"], budget, seed)
                prior = archive[(archive.case == case) & (archive["mode"] == mode) &
                                (archive.seed == seed) & (archive.method == method)].iloc[0]
                max_diff = max(max_diff, *(abs(float(result[f]) - float(prior[f])) for f in fields))
                count += 1
print(f"Verified {count} saved runs and all exact/reference values; max absolute difference {max_diff:.3g}")
assert count == 288 and max_diff < 1e-12

# The main QACO records are also retained as a separate 20-ant run file.
batched = pd.read_csv(ROOT / "data" / "qaco_batched_reproduction_runs.csv")
batched_max_diff = 0.0
batched_count = 0
for case, width, outdeg, graph_seed, budget in specs:
    graph = exp.generate_aeb_graph(case, width, outdeg, seed=graph_seed)
    cache = exp.build_benchmark_cache({case: graph})[case]
    for mode in ("mult", "add"):
        for seed in range(1, 13):
            result = exp.run_qaco(graph, mode, cache[f"ref_{mode}"],
                                  cache[f"thr_{mode}"], budget, seed)
            prior = batched[(batched.case == case) & (batched["mode"] == mode) &
                            (batched.seed == seed)].iloc[0]
            batched_max_diff = max(batched_max_diff,
                                   *(abs(float(result[f]) - float(prior[f])) for f in fields))
            batched_count += 1
print(f"Verified {batched_count} 20-ant, 50-round QACO reruns; max non-timing difference {batched_max_diff:.3g}")
assert batched_count == 96 and batched_max_diff < 1e-12

# Verify revised QACO parameter and threshold records, excluding wall-clock time.
import revision_analysis

saved_sensitivity = pd.read_csv(ROOT / "data" / "qaco_parameter_sensitivity_runs.csv")
new_sensitivity, _ = revision_analysis.run_parameter_sensitivity(n_seeds=12)
key = ["parameter", "value", "seed"]
joined = saved_sensitivity.merge(new_sensitivity, on=key, suffixes=("_saved", "_new"),
                                 validate="one_to_one")
assert len(joined) == 108
for field in fields:
    assert (joined[f"{field}_saved"] - joined[f"{field}_new"]).abs().max() < 1e-12, field

saved_threshold = pd.read_csv(ROOT / "data" / "threshold_sensitivity_qaco_runs.csv")
graph = exp.generate_aeb_graph("AEB-S4", 34, 5, seed=4)
cache = exp.build_benchmark_cache({"AEB-S4": graph})["AEB-S4"]
for _, prior in saved_threshold.iterrows():
    fresh = exp.run_qaco(graph, "add", cache["ref_add"],
                                  cache["ref_add"] * float(prior["threshold_fraction"]),
                                  420, int(prior["seed"]))
    assert max(abs(float(fresh[f]) - float(prior[f])) for f in fields) < 1e-12
print("Verified 108 parameter-sensitivity and 72 threshold-sensitivity QACO records.")
