"""Render result figures from the accompanying summary CSV files."""
from pathlib import Path
import shutil
import subprocess

import pandas as pd
from reportlab.lib.colors import HexColor
from reportlab.pdfgen import canvas

ROOT = Path(__file__).resolve().parents[1]
DATA, FIG = ROOT / "data", ROOT / "figures"
METHODS = ["ACO", "GA", "QACO", "Tabu"]
CASES = ["AEB-S1", "AEB-S2", "AEB-S3", "AEB-S4"]
BAR = {"ACO": "#d87745", "GA": "#4ba254", "QACO": "#75618e", "Tabu": "#d9cc22"}
LINE = {"ACO": "#df7759", "GA": "#3e435f", "QACO": "#80ae9a", "Tabu": "#f0c879"}


def color(c, value):
    c.setFillColor(HexColor(value))
    c.setStrokeColor(HexColor(value))


def center(c, text, x, y, size=12, bold=False):
    c.setFont("Times-Bold" if bold else "Times-Roman", size)
    c.drawCentredString(x, y, text)


def vertical(c, text, x, y, size=16):
    c.saveState()
    c.translate(x, y)
    c.rotate(90)
    center(c, text, 0, 0, size, True)
    c.restoreState()


def finish(c, stem):
    c.showPage()
    c.save()
    tool = shutil.which("pdftoppm") or r"C:\texlive\2026\bin\windows\pdftoppm.exe"
    subprocess.run([tool, "-f", "1", "-l", "1", "-singlefile", "-r", "216",
                    "-png", str(FIG / (stem + ".pdf")), str(FIG / stem)],
                   check=True, stdout=subprocess.DEVNULL)


def panel(c, data, metric, ylabel, tag, x0, y0, w, h, ymax, tick, show_legend=False):
    color(c, "#111111")
    c.setLineWidth(0.9)
    c.rect(x0, y0, w, h, fill=0, stroke=1)
    k = 0
    while k * tick <= ymax + 1e-9:
        val = k * tick
        yy = y0 + h * val / ymax
        if k:
            color(c, "#c9c9c9")
            c.setDash(3, 3)
            c.line(x0, yy, x0 + w, yy)
            c.setDash()
        color(c, "#111111")
        c.setFont("Times-Roman", 10)
        c.drawRightString(x0 - 7, yy - 3, f"{val:.2f}" if ymax < 1 else f"{val:g}")
        k += 1
    vertical(c, ylabel, x0 - 58, y0 + h / 2)
    c.setFont("Times-Bold", 18)
    c.drawString(x0 + 8, y0 + h - 24, tag)
    if show_legend:
        lx = x0 + w - 450
        for method in METHODS:
            color(c, BAR[method])
            c.rect(lx, y0 + h - 24, 16, 11, fill=1, stroke=0)
            color(c, "#111111")
            c.setFont("Times-Roman", 12)
            c.drawString(lx + 22, y0 + h - 24, method)
            lx += 105
    group_w = w / 4
    for gi, case in enumerate(CASES):
        gx = x0 + group_w * (gi + 0.5)
        for mi, method in enumerate(METHODS):
            val = float(data[(data.case == case) & (data.method == method)][metric].iloc[0])
            bx = gx + (mi - 1.5) * 38 - 15
            color(c, BAR[method])
            c.rect(bx, y0, 30, max(0, min(h, h * val / ymax)), fill=1, stroke=0)
            color(c, "#111111")
            center(c, method, bx + 15, y0 - 15, 9)
        center(c, case, gx, y0 - 32, 12, True)


def bar_figures():
    data = pd.read_csv(DATA / "by_scale_results_with_ci.csv")
    for stem, spec in [
        ("fig7-8", ("exact_ratio_mean", "Exact-value ratio", 0.14, 0.02,
                    "runtime_ms_mean", "Runtime (ms)", 12.0, 2.0)),
        ("fig9-10", ("compactness_mean", "Compactness", 0.53, 0.1,
                     "success_mean", "Success rate", 1.07, 0.2)),
    ]:
        c = canvas.Canvas(str(FIG / (stem + ".pdf")), pagesize=(1047, 780))
        panel(c, data, spec[0], spec[1], "(A)", 100, 440, 900, 290, spec[2], spec[3], True)
        panel(c, data, spec[4], spec[5], "(B)", 100, 88, 900, 270, spec[6], spec[7])
        color(c, "#111111")
        center(c, "AEB benchmark scale", 523, 25, 17, True)
        finish(c, stem)


def mode_figure():
    data = pd.read_csv(DATA / "by_mode_results_with_ci.csv")
    c = canvas.Canvas(str(FIG / "fig11.pdf"), pagesize=(1141, 797))
    mid, scale = 590, 480
    color(c, "#111111")
    c.setLineWidth(1.1)
    c.rect(150, 115, 880, 620, fill=0, stroke=1)
    c.line(mid, 115, mid, 735)
    for i, method in enumerate(METHODS):
        y = 195 + i * 145
        left = float(data[(data.method == method) & (data["mode"] == "add")].compact_ratio_mean.iloc[0])
        right = float(data[(data.method == method) & (data["mode"] == "mult")].compact_ratio_mean.iloc[0])
        color(c, "#e9af9e")
        c.rect(mid - left * scale, y - 42, left * scale, 84, fill=1, stroke=0)
        color(c, "#b3cfc3")
        c.rect(mid, y - 42, right * scale, 84, fill=1, stroke=0)
        color(c, "#303030")
        center(c, f"{left:.5f}", mid - left * scale / 2, y - 6, 19, True)
        center(c, f"{right:.5f}", mid + right * scale / 2, y - 6, 19, True)
        c.setFont("Times-Roman", 22)
        c.drawRightString(130, y - 8, method)
    color(c, "#111111")
    for tick in range(-10, 11, 2):
        x = mid + tick / 10 * scale
        c.line(x, 115, x, 105)
        center(c, f"{abs(tick / 10):.1f}", x, 82, 15)
    center(c, "Additive", 370, 38, 21, True)
    center(c, "Multiplicative", 810, 38, 21, True)
    color(c, "#e9af9e")
    c.rect(370, 756, 28, 20, fill=1, stroke=0)
    color(c, "#111111")
    c.setFont("Times-Bold", 18)
    c.drawString(250, 758, "Additive")
    color(c, "#b3cfc3")
    c.rect(610, 756, 28, 20, fill=1, stroke=0)
    color(c, "#111111")
    c.drawString(645, 758, "Multiplicative")
    finish(c, "fig11")


def threshold_runtime():
    data = pd.read_csv(DATA / "figure12_13_source.csv")
    c = canvas.Canvas(str(FIG / "fig13.pdf"), pagesize=(1072, 820))
    x0, x1 = 145, 910
    fractions = sorted(data.threshold_fraction.unique())
    for idx, method in enumerate(METHODS):
        y0, h = [620, 438, 256, 74][idx], 146
        color(c, "#111111")
        c.setLineWidth(1.0)
        c.rect(x0, y0, x1 - x0, h, fill=0, stroke=1)
        for value in range(2, 15, 2):
            yy = y0 + h * (value - 1) / 13.5
            c.setFont("Times-Roman", 10)
            c.drawRightString(x0 - 8, yy - 3, str(value))
            c.line(x0, yy, x0 + 6, yy)
        d = data[data.method == method].sort_values("threshold_fraction")
        values = d.time_ms_mean.to_numpy(dtype=float)
        points = [(x0 + 58 + (x1 - x0 - 116) * i / 5,
                   y0 + h * (float(v) - 1) / 13.5) for i, v in enumerate(values)]
        color(c, LINE[method])
        c.setLineWidth(2.5)
        path = c.beginPath()
        path.moveTo(*points[0])
        for point in points[1:]:
            path.lineTo(*point)
        c.drawPath(path, stroke=1, fill=0)
        for (x, y), value in zip(points, values):
            c.circle(x, y, 6, fill=1, stroke=0)
            color(c, "#222222")
            center(c, f"{value:.2f}", x, y + (13 if method != "GA" else -21), 11)
            color(c, LINE[method])
        c.setFont("Times-Bold", 18)
        c.drawString(x1 + 17, y0 + h / 2, method)
        if idx == 3:
            color(c, "#111111")
            for (x, _), fraction in zip(points, fractions):
                center(c, f"{fraction:.2f}", x, y0 - 25, 12)
    vertical(c, "Runtime (ms)", 48, 410, 18)
    color(c, "#111111")
    center(c, "Threshold fraction", 530, 17, 17, True)
    finish(c, "fig13")


def threshold_exact_ratio():
    data = pd.read_csv(DATA / "figure12_13_source.csv")
    c = canvas.Canvas(str(FIG / "fig12.pdf"), pagesize=(1072, 820))
    x0, x1 = 145, 910
    fractions = sorted(data.threshold_fraction.unique())
    lower, upper = 0.0016, 0.0033
    for idx, method in enumerate(METHODS):
        y0, h = [620, 438, 256, 74][idx], 146
        color(c, "#111111")
        c.setLineWidth(1.0)
        c.rect(x0, y0, x1 - x0, h, fill=0, stroke=1)
        for tick in range(16, 33, 2):
            value = tick / 10000
            yy = y0 + h * (value - lower) / (upper - lower)
            c.setFont("Times-Roman", 10)
            c.drawRightString(x0 - 8, yy - 3, f"{value:.4f}")
            c.line(x0, yy, x0 + 6, yy)
        d = data[data.method == method].sort_values("threshold_fraction")
        values = d.exact_ratio_mean.to_numpy(dtype=float)
        points = [(x0 + 58 + (x1 - x0 - 116) * i / 5,
                   y0 + h * (float(v) - lower) / (upper - lower))
                  for i, v in enumerate(values)]
        color(c, LINE[method])
        c.setLineWidth(2.5)
        path = c.beginPath()
        path.moveTo(*points[0])
        for point in points[1:]:
            path.lineTo(*point)
        c.drawPath(path, stroke=1, fill=0)
        for (x, y), value in zip(points, values):
            c.circle(x, y, 6, fill=1, stroke=0)
            color(c, "#222222")
            center(c, f"{value:.5f}", x, y + 13, 11)
            color(c, LINE[method])
        c.setFont("Times-Bold", 18)
        c.drawString(x1 + 17, y0 + h / 2, method)
        if idx == 3:
            color(c, "#111111")
            for (x, _), fraction in zip(points, fractions):
                center(c, f"{fraction:.2f}", x, y0 - 25, 12)
    vertical(c, "Exact-value ratio", 48, 410, 18)
    color(c, "#111111")
    center(c, "Threshold fraction", 530, 17, 17, True)
    finish(c, "fig12")


if __name__ == "__main__":
    FIG.mkdir(exist_ok=True)
    bar_figures()
    mode_figure()
    threshold_exact_ratio()
    threshold_runtime()
    print("Rendered five result figure assets from the summary CSV files.")
