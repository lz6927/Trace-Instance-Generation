
import os
import time
import random
from dataclasses import dataclass
from collections import defaultdict, deque
from functools import lru_cache

import numpy as np
import pandas as pd

try:
    import matplotlib.pyplot as plt
except ImportError:  # The numerical CSV outputs should remain reproducible without plotting dependencies.
    plt = None


@dataclass
class Node:
    id: int
    stage: int
    idx: int
    kind: str
    module: str
    mult_value: float = 1.0
    add_value: float = 0.0


@dataclass
class Edge:
    src: int
    dst: int
    prob: float
    dt: float
    cost: float


@dataclass
class Graph:
    nodes: dict
    edges_out: dict
    start: int
    success: int
    fail: int
    stages: list
    name: str
    width: int
    outdeg: int
    module_names: list
    time_bound: float


def generate_aeb_graph(name: str, width: int, outdeg: int, seed: int = 0) -> Graph:
    rng = random.Random(seed)
    module_names = [
        "sensor acquisition",
        "fusion and filtering",
        "threat scoring",
        "braking policy",
        "actuator allocation",
        "hydraulic execution",
        "slip stability control",
        "fault recovery and confirmation",
    ]
    n_stages = len(module_names)
    nodes = {}
    edges_out = {}
    nid = 0
    start = nid
    nodes[nid] = Node(nid, -1, 0, "start", "start", 1.0, 0.0)
    nid += 1
    stages = []
    corridor = [rng.randrange(width) for _ in range(n_stages)]

    for s in range(n_stages):
        stage_nodes = []
        for j in range(width):
            dist = min((j - corridor[s]) % width, (corridor[s] - j) % width)
            base_mult = 0.96 - 0.012 * s
            mv = max(0.72, min(0.985, base_mult - 0.012 * dist + rng.uniform(-0.006, 0.006)))
            base_add = 1.02 - 0.05 * s
            av = max(0.18, min(1.15, base_add - 0.08 * dist + rng.uniform(-0.03, 0.03)))
            nodes[nid] = Node(nid, s, j, "regular", module_names[s], mv, av)
            stage_nodes.append(nid)
            nid += 1
        stages.append(stage_nodes)

    success = nid
    nodes[nid] = Node(nid, n_stages, 0, "success", "safe stop confirmed", 1.0, 0.0)
    nid += 1
    fail = nid
    nodes[nid] = Node(nid, n_stages, 1, "fail", "unsafe termination", 1.0, 0.0)
    nid += 1

    for node_id in nodes:
        edges_out[node_id] = []

    def neighbor_indices(stage: int, j: int, next_width: int, d: int):
        candidates = []
        for k in range(next_width):
            local_term = abs(((k - j + next_width // 2) % next_width) - next_width // 2)
            corridor_term = abs(((k - corridor[stage + 1] + next_width // 2) % next_width) - next_width // 2)
            candidates.append((local_term + 0.6 * corridor_term, k))
        candidates.sort()
        chosen = []
        used = set()
        offsets = [0, 1, -1, 2, -2, next_width // 3, -(next_width // 3), next_width // 2]
        for off in offsets:
            k = (j + off) % next_width
            if k not in used:
                chosen.append(k)
                used.add(k)
            if len(chosen) >= d:
                break
        if len(chosen) < d:
            for _, k in candidates:
                if k not in used:
                    chosen.append(k)
                    used.add(k)
                if len(chosen) >= d:
                    break
        return chosen[:d]

    first_inds = [corridor[0]]
    step = max(1, width // max(outdeg, 1))
    k = 0
    while len(first_inds) < outdeg:
        cand = (corridor[0] + (k + 1) * step) % width
        if cand not in first_inds:
            first_inds.append(cand)
        k += 1
    raw = []
    for j in first_inds[:outdeg]:
        closeness = abs(((j - corridor[0] + width // 2) % width) - width // 2)
        weight = max(0.2, 1.4 - 0.18 * closeness + rng.uniform(-0.03, 0.03))
        raw.append(weight)
    ssum = sum(raw)
    probs = [x / ssum for x in raw]
    for j, p in zip(first_inds[:outdeg], probs):
        dst = stages[0][j]
        dt = round(rng.uniform(0.18, 0.36), 3)
        cost = round(rng.uniform(0.05, 0.12), 3)
        edges_out[start].append(Edge(start, dst, p, dt, cost))

    for s in range(n_stages - 1):
        for node_id in stages[s]:
            j = nodes[node_id].idx
            neigh = neighbor_indices(s, j, width, outdeg)
            weights = []
            for k in neigh:
                closeness_next = abs(((k - corridor[s + 1] + width // 2) % width) - width // 2)
                w = max(0.08, 1.5 - 0.16 * closeness_next + rng.uniform(-0.04, 0.04))
                weights.append(w)
            wsum = sum(weights)
            probs = [w / wsum for w in weights]
            for k, p in zip(neigh, probs):
                dst = stages[s + 1][k]
                dt = round(rng.uniform(0.22, 0.55), 3)
                closeness = abs(((k - corridor[s + 1] + width // 2) % width) - width // 2)
                cost = round(0.06 + 0.012 * closeness + rng.uniform(0.0, 0.03), 3)
                edges_out[node_id].append(Edge(node_id, dst, p, dt, cost))

    last = n_stages - 1
    for node_id in stages[last]:
        j = nodes[node_id].idx
        closeness = abs(((j - corridor[last] + width // 2) % width) - width // 2)
        succ_w = max(0.05, 1.7 - 0.18 * closeness + rng.uniform(-0.04, 0.04))
        fail_w = max(0.05, 0.35 + 0.16 * closeness + rng.uniform(-0.03, 0.03))
        tot = succ_w + fail_w
        p_succ = succ_w / tot
        p_fail = fail_w / tot
        dt_s = round(rng.uniform(0.18, 0.42), 3)
        dt_f = round(rng.uniform(0.18, 0.42), 3)
        cost_s = round(0.04 + 0.01 * closeness + rng.uniform(0.0, 0.02), 3)
        cost_f = round(0.10 + 0.015 * closeness + rng.uniform(0.0, 0.03), 3)
        edges_out[node_id].append(Edge(node_id, success, p_succ, dt_s, cost_s))
        edges_out[node_id].append(Edge(node_id, fail, p_fail, dt_f, cost_f))

    graph = Graph(nodes, edges_out, start, success, fail, stages, name, width, outdeg, module_names, 0.0)
    graph.time_bound = round(max_time_to_success(graph) + 1e-6, 3)
    return graph


def max_time_to_success(graph: Graph) -> float:
    @lru_cache(None)
    def f(node_id):
        if node_id == graph.success:
            return 0.0
        if node_id == graph.fail:
            return -1e18
        best = -1e18
        for e in graph.edges_out[node_id]:
            child = f(e.dst)
            if child > -1e17:
                best = max(best, e.dt + child)
        return best
    return f(graph.start)


def enumerate_paths(graph: Graph):
    paths = []

    def dfs(node_id, path_nodes, path_edges, time_acc):
        if node_id == graph.success:
            paths.append((path_nodes.copy(), path_edges.copy(), time_acc))
            return
        if node_id == graph.fail:
            return
        for e in graph.edges_out[node_id]:
            new_t = time_acc + e.dt
            if new_t <= graph.time_bound + 1e-9:
                path_nodes.append(e.dst)
                path_edges.append(e)
                dfs(e.dst, path_nodes, path_edges, new_t)
                path_nodes.pop()
                path_edges.pop()

    dfs(graph.start, [graph.start], [], 0.0)
    return paths


def path_contribution(graph: Graph, path_nodes, path_edges, mode: str) -> float:
    regular_nodes = [graph.nodes[n] for n in path_nodes if graph.nodes[n].kind == "regular"]
    prob_prod = 1.0
    for e in path_edges:
        prob_prod *= e.prob
    if mode == "mult":
        val = 1.0
        for n in regular_nodes:
            val *= n.mult_value
        return val * prob_prod
    if mode == "add":
        val = sum(n.add_value for n in regular_nodes)
        return val * prob_prod
    raise ValueError(mode)


def dp_mult_add(graph: Graph):
    @lru_cache(None)
    def succ_prob(node_id):
        if node_id == graph.success:
            return 1.0
        if node_id == graph.fail:
            return 0.0
        return sum(e.prob * succ_prob(e.dst) for e in graph.edges_out[node_id])

    @lru_cache(None)
    def mult_val(node_id):
        node = graph.nodes[node_id]
        if node_id == graph.success:
            return 1.0
        if node_id == graph.fail:
            return 0.0
        factor = node.mult_value if node.kind == "regular" else 1.0
        return sum(e.prob * factor * mult_val(e.dst) for e in graph.edges_out[node_id])

    @lru_cache(None)
    def add_val(node_id):
        node = graph.nodes[node_id]
        if node_id == graph.success or node_id == graph.fail:
            return 0.0
        add_here = node.add_value if node.kind == "regular" else 0.0
        total = 0.0
        for e in graph.edges_out[node_id]:
            total += e.prob * (add_here * succ_prob(e.dst) + add_val(e.dst))
        return total

    return succ_prob(graph.start), mult_val(graph.start), add_val(graph.start)


def immediate_heuristic(graph: Graph, e: Edge, mode: str) -> float:
    dst = graph.nodes[e.dst]
    if mode == "mult":
        node_factor = dst.mult_value if dst.kind == "regular" else (1.0 if dst.kind == "success" else 0.2)
        return max(1e-9, e.prob * node_factor)
    node_factor = dst.add_value if dst.kind == "regular" else (0.2 if dst.kind == "success" else 0.02)
    return max(1e-9, e.prob * (node_factor + 0.1))


def rollout_path(graph: Graph, rng: random.Random, chooser):
    node = graph.start
    nodes = [node]
    edges = []
    while True:
        outs = graph.edges_out[node]
        if not outs:
            break
        e = chooser(node, outs, nodes, edges)
        edges.append(e)
        nodes.append(e.dst)
        node = e.dst
        if node in (graph.success, graph.fail):
            break
    return nodes, edges


def path_edges_from_nodes(graph: Graph, nodes_seq):
    edges = []
    for a, b in zip(nodes_seq[:-1], nodes_seq[1:]):
        e = next(e for e in graph.edges_out[a] if e.dst == b)
        edges.append(e)
    return edges


def random_rollout_from(graph: Graph, start_node: int, rng: random.Random, mode: str, bias=0.7):
    node = start_node
    nodes = [node]
    while node not in (graph.success, graph.fail):
        outs = graph.edges_out[node]
        hs = [immediate_heuristic(graph, e, mode) for e in outs]
        if rng.random() < bias:
            total = sum(hs)
            r = rng.random() * total
            c = 0.0
            choice = outs[-1]
            for e, h in zip(outs, hs):
                c += h
                if c >= r:
                    choice = e
                    break
        else:
            choice = rng.choice(outs)
        node = choice.dst
        nodes.append(node)
    return nodes


def generate_random_path(graph: Graph, mode: str, rng: random.Random, bias=0.7):
    return random_rollout_from(graph, graph.start, rng, mode, bias=bias)


def contrib_of(graph: Graph, path_nodes, path_edges, mode: str):
    return path_contribution(graph, path_nodes, path_edges, mode)


def compute_metrics_from_paths(graph: Graph, accepted_paths: dict, compact_ref: float, threshold: float, mode: str):
    total = sum(v[2] for v in accepted_paths.values())
    unique_nodes = set()
    unique_edges = set()
    for pn, pe, contrib in accepted_paths.values():
        unique_nodes.update(pn)
        unique_edges.update((e.src, e.dst) for e in pe)
    total_nodes = len(graph.nodes)
    total_edges = sum(len(v) for v in graph.edges_out.values())
    compactness = (len(unique_nodes) + len(unique_edges)) / (total_nodes + total_edges)
    return {
        "returned_value": total,
        "reference_coverage": total / compact_ref if compact_ref > 0 else 0.0,
        "reference_gap": max(0.0, compact_ref - total),
        "compactness": compactness,
        "success": 1.0 if total >= threshold - 1e-12 else 0.0,
        "accepted_paths": len(accepted_paths),
    }


def compute_best_potential(graph: Graph, mode: str):
    @lru_cache(None)
    def f(node_id):
        node = graph.nodes[node_id]
        if node_id == graph.success:
            return 1.0 if mode == "mult" else 0.0
        if node_id == graph.fail:
            return 0.0
        vals = []
        for e in graph.edges_out[node_id]:
            child = f(e.dst)
            if mode == "mult":
                factor = node.mult_value if node.kind == "regular" else 1.0
                vals.append(e.prob * factor * child)
            else:
                add_here = node.add_value if node.kind == "regular" else 0.0
                vals.append(e.prob * (add_here + child) if graph.nodes[e.dst].kind in ("success", "regular") else 0.0)
        return max(vals) if vals else 0.0

    return {nid: f(nid) for nid in graph.nodes}


def run_aco(graph: Graph, mode: str, compact_ref: float, threshold: float, budget: int, seed: int,
            alpha=1.0, beta=1.6, evap=0.10, deposit_scale=25.0):
    rng = random.Random(seed)
    pher = defaultdict(lambda: 1.0)
    accepted = {}
    evals = 0
    t0 = time.perf_counter()

    while evals < budget:
        def chooser(node, outs, nodes, edges):
            weights = []
            for e in outs:
                h = immediate_heuristic(graph, e, mode)
                w = (pher[(e.src, e.dst)] ** alpha) * (h ** beta)
                weights.append(max(w, 1e-12))
            total = sum(weights)
            r = rng.random() * total
            c = 0.0
            for e, w in zip(outs, weights):
                c += w
                if c >= r:
                    return e
            return outs[-1]

        pn, pe = rollout_path(graph, rng, chooser)
        evals += 1
        if pn[-1] == graph.success:
            c = contrib_of(graph, pn, pe, mode)
            sig = tuple(pn)
            if c > 0 and sig not in accepted:
                accepted[sig] = (pn, pe, c)
                dep = deposit_scale * c / max(1, len(pe))
                for e in pe:
                    pher[(e.src, e.dst)] += dep
        if evals % 4 == 0:
            for k in list(pher.keys()):
                pher[k] *= (1 - evap)
                if pher[k] < 0.05:
                    pher[k] = 0.05
        if sum(v[2] for v in accepted.values()) >= threshold:
            break

    runtime_ms = (time.perf_counter() - t0) * 1000
    metrics = compute_metrics_from_paths(graph, accepted, compact_ref, threshold, mode)
    metrics.update({"runtime_ms": runtime_ms, "evals": evals, "method": "ACO"})
    return metrics


def crossover_paths(graph: Graph, p1, p2, rng: random.Random, mode: str):
    cut = rng.randint(2, len(p1) - 3)
    prefix = p1[:cut]
    last = prefix[-1]
    target_suffix = p2[cut:]
    nodes = prefix.copy()
    node = last
    for target in target_suffix:
        if node in (graph.success, graph.fail):
            break
        valid_dsts = [e.dst for e in graph.edges_out[node]]
        if target in valid_dsts:
            node = target
            nodes.append(node)
        else:
            suffix = random_rollout_from(graph, node, rng, mode, bias=0.8)
            nodes.extend(suffix[1:])
            node = nodes[-1]
            break
    if nodes[-1] not in (graph.success, graph.fail):
        suffix = random_rollout_from(graph, node, rng, mode, bias=0.8)
        nodes.extend(suffix[1:])
    return nodes


def mutate_path(graph: Graph, p, rng: random.Random, mode: str):
    cut = rng.randint(1, len(p) - 3)
    prefix = p[:cut]
    node = prefix[-1]
    suffix = random_rollout_from(graph, node, rng, mode, bias=0.45)
    return prefix + suffix[1:]


def path_score(graph: Graph, nodes_seq, mode: str) -> float:
    if nodes_seq[-1] != graph.success:
        return 0.0
    pe = path_edges_from_nodes(graph, nodes_seq)
    return contrib_of(graph, nodes_seq, pe, mode)


def run_ga(graph: Graph, mode: str, compact_ref: float, threshold: float, budget: int, seed: int,
           pop_size=18, elite_size=4, mutation_rate=0.35):
    rng = random.Random(seed)
    t0 = time.perf_counter()
    accepted = {}
    evals = 0
    population = []

    for _ in range(pop_size):
        path = generate_random_path(graph, mode, rng, bias=0.65)
        population.append(path)
        evals += 1
        if path[-1] == graph.success:
            pe = path_edges_from_nodes(graph, path)
            c = contrib_of(graph, path, pe, mode)
            sig = tuple(path)
            if c > 0 and sig not in accepted:
                accepted[sig] = (path, pe, c)
        if evals >= budget:
            break

    while evals < budget and sum(v[2] for v in accepted.values()) < threshold:
        scored = [(path_score(graph, p, mode), p) for p in population]
        scored.sort(key=lambda x: x[0], reverse=True)
        elites = [p for _, p in scored[:elite_size]]
        for p in elites:
            if p[-1] == graph.success:
                pe = path_edges_from_nodes(graph, p)
                c = contrib_of(graph, p, pe, mode)
                sig = tuple(p)
                if c > 0 and sig not in accepted:
                    accepted[sig] = (p, pe, c)
        new_pop = elites.copy()

        def select_parent():
            cand = random.sample(scored, k=min(4, len(scored)))
            cand.sort(key=lambda x: x[0], reverse=True)
            return cand[0][1]

        while len(new_pop) < pop_size and evals < budget:
            p1 = select_parent()
            p2 = select_parent()
            child = crossover_paths(graph, p1, p2, rng, mode)
            if rng.random() < mutation_rate:
                child = mutate_path(graph, child, rng, mode)
            new_pop.append(child)
            evals += 1
            if child[-1] == graph.success:
                pe = path_edges_from_nodes(graph, child)
                c = contrib_of(graph, child, pe, mode)
                sig = tuple(child)
                if c > 0 and sig not in accepted:
                    accepted[sig] = (child, pe, c)
        population = new_pop

    runtime_ms = (time.perf_counter() - t0) * 1000
    metrics = compute_metrics_from_paths(graph, accepted, compact_ref, threshold, mode)
    metrics.update({"runtime_ms": runtime_ms, "evals": evals, "method": "GA"})
    return metrics


def greedy_path(graph: Graph, mode: str):
    node = graph.start
    nodes = [node]
    while node not in (graph.success, graph.fail):
        outs = graph.edges_out[node]
        best = max(outs, key=lambda e: immediate_heuristic(graph, e, mode))
        node = best.dst
        nodes.append(node)
    return nodes


def neighbor_paths(graph: Graph, current, rng: random.Random, mode: str, n_neighbors=4):
    neigh = []
    for _ in range(n_neighbors):
        cut = rng.randint(1, len(current) - 3)
        prefix = current[:cut]
        node = prefix[-1]
        suffix = random_rollout_from(graph, node, rng, mode, bias=0.35)
        neigh.append(prefix + suffix[1:])
    return neigh


def run_tabu(graph: Graph, mode: str, compact_ref: float, threshold: float, budget: int, seed: int,
             tabu_tenure=14, n_neighbors=4, diversify_every=5):
    rng = random.Random(seed)
    t0 = time.perf_counter()
    accepted = {}
    evals = 0
    current = greedy_path(graph, mode)
    tabu = deque(maxlen=tabu_tenure)

    while evals < budget and sum(v[2] for v in accepted.values()) < threshold:
        if current[-1] == graph.success:
            pe = path_edges_from_nodes(graph, current)
            c = contrib_of(graph, current, pe, mode)
            sig = tuple(current)
            if c > 0 and sig not in accepted:
                accepted[sig] = (current, pe, c)

        best_choice = None
        best_score = -1.0
        for p in neighbor_paths(graph, current, rng, mode, n_neighbors):
            evals += 1
            s = path_score(graph, p, mode)
            if p[-1] == graph.success and s > 0:
                sig = tuple(p)
                if sig not in accepted:
                    pe = path_edges_from_nodes(graph, p)
                    accepted[sig] = (p, pe, s)
            if tuple(p) not in tabu and s > best_score:
                best_score = s
                best_choice = p
            if evals >= budget:
                break

        current = best_choice if best_choice is not None else generate_random_path(graph, mode, rng, bias=0.2)
        tabu.append(tuple(current))
        if len(tabu) % diversify_every == 0:
            current = generate_random_path(graph, mode, rng, bias=0.2)

    runtime_ms = (time.perf_counter() - t0) * 1000
    metrics = compute_metrics_from_paths(graph, accepted, compact_ref, threshold, mode)
    metrics.update({"runtime_ms": runtime_ms, "evals": evals, "method": "Tabu"})
    return metrics


def run_qaco_archived(graph: Graph, mode: str, compact_ref: float, threshold: float, budget: int, seed: int, overrides=None):
    params = {
        "greedy": 0.25,
        "alpha": 1.0,
        "beta": 1.2,
        "gamma_h": 1.6,
        "pot_w": 0.4,
        "pot_bonus": 0.10,
        "deposit_scale": 80.0,
        "delta_w": 3.3,
        "lr": 0.50,
        "gamma_q": 0.90,
        "hit_bonus": 0.70,
        "fail_penalty": 0.20,
        "dt_pen": 0.04,
        "cost_pen": 0.03,
        "dup_penalty": 0.01,
        "evap": 0.04,
        "evap_every": 4,
    }
    if overrides:
        params.update(overrides)
    rng = random.Random(seed)
    pher = defaultdict(lambda: 1.0)
    potential = compute_best_potential(graph, mode)
    scale_pot = max(potential.values()) if max(potential.values()) > 0 else 1.0
    Q = defaultdict(float)
    for src, outs in graph.edges_out.items():
        for e in outs:
            Q[(e.src, e.dst)] = max(1e-6, potential[e.dst] * e.prob)

    accepted = {}
    evals = 0
    t0 = time.perf_counter()

    while evals < budget:
        node = graph.start
        pn = [node]
        pe = []
        step = 0

        while node not in (graph.success, graph.fail):
            outs = graph.edges_out[node]
            if rng.random() < params["greedy"]:
                e = max(
                    outs,
                    key=lambda x: (pher[(x.src, x.dst)] ** params["alpha"])
                    * (max(Q[(x.src, x.dst)], 1e-8) ** params["beta"])
                    * (immediate_heuristic(graph, x, mode) ** params["gamma_h"]),
                )
            else:
                ws = []
                for e0 in outs:
                    h = immediate_heuristic(graph, e0, mode)
                    q = max(Q[(e0.src, e0.dst)], 1e-8)
                    extra = 1 + params["pot_w"] * potential[e0.dst]
                    w = (pher[(e0.src, e0.dst)] ** params["alpha"]) * (q ** params["beta"]) * (h ** params["gamma_h"]) * extra
                    if step < 2:
                        w *= 1 + 0.5 * potential[e0.dst] / scale_pot
                    ws.append(max(w, 1e-12))
                total = sum(ws)
                r = rng.random() * total
                c = 0.0
                e = outs[-1]
                for e0, w in zip(outs, ws):
                    c += w
                    if c >= r:
                        e = e0
                        break
            pe.append(e)
            pn.append(e.dst)
            node = e.dst
            step += 1

        evals += 1
        is_duplicate = pn[-1] == graph.success and tuple(pn) in accepted
        score_prev = 0.0
        curr_prob = 1.0
        curr_val = 1.0 if mode == "mult" else 0.0
        rewards = []

        for idx, e in enumerate(pe):
            src = graph.nodes[e.src]
            curr_prob *= e.prob
            if src.kind == "regular":
                if mode == "mult":
                    curr_val *= src.mult_value
                else:
                    curr_val += src.add_value
            score = curr_prob * curr_val
            delta = score - score_prev
            score_prev = score
            if idx == len(pe) - 1 and e.dst == graph.success:
                terminal_bonus = params["hit_bonus"]
            elif idx == len(pe) - 1 and e.dst == graph.fail:
                terminal_bonus = -params["fail_penalty"]
            else:
                terminal_bonus = 0.0
            duplicate_cost = params["dup_penalty"] if is_duplicate and idx == len(pe) - 1 else 0.0
            rewards.append(params["delta_w"] * delta + terminal_bonus - params["dt_pen"] * e.dt
                           - params["cost_pen"] * e.cost - duplicate_cost)

        for e, r in zip(reversed(pe), reversed(rewards)):
            future = 0.0 if e.dst in (graph.success, graph.fail) else max(Q[(x.src, x.dst)] for x in graph.edges_out[e.dst])
            key = (e.src, e.dst)
            Q[key] = (1 - params["lr"]) * Q[key] + params["lr"] * (r + params["gamma_q"] * future + params["pot_bonus"] * potential[e.dst])

        if pn[-1] == graph.success:
            c = contrib_of(graph, pn, pe, mode)
            sig = tuple(pn)
            if c > 0 and sig not in accepted:
                accepted[sig] = (pn, pe, c)
                dep = params["deposit_scale"] * c / max(1, len(pe))
                for e in pe:
                    pher[(e.src, e.dst)] += dep

        if evals % params["evap_every"] == 0:
            for k in list(pher.keys()):
                pher[k] *= (1 - params["evap"])
                if pher[k] < 0.05:
                    pher[k] = 0.05

        if sum(v[2] for v in accepted.values()) >= threshold:
            break

    runtime_ms = (time.perf_counter() - t0) * 1000
    metrics = compute_metrics_from_paths(graph, accepted, compact_ref, threshold, mode)
    metrics.update({"runtime_ms": runtime_ms, "evals": evals, "method": "QACO"})
    return metrics


def run_qaco(graph: Graph, mode: str, compact_ref: float, threshold: float, budget: int, seed: int, overrides=None):
    params = {
        "greedy": 0.25,
        "alpha": 1.0,
        "beta": 1.2,
        "gamma_h": 1.6,
        "pot_w": 0.4,
        "pot_bonus": 0.10,
        "deposit_scale": 80.0,
        "delta_w": 3.3,
        "lr": 0.50,
        "gamma_q": 0.90,
        "hit_bonus": 0.70,
        "fail_penalty": 0.20,
        "dt_pen": 0.04,
        "cost_pen": 0.03,
        "dup_penalty": 0.01,
        "evap": 0.15,
        "ants": 20,
        "max_rounds": 50,
    }
    if overrides:
        params.update(overrides)
    rng = random.Random(seed)
    pher = defaultdict(lambda: 1.0)
    potential = compute_best_potential(graph, mode)
    scale_pot = max(potential.values()) if max(potential.values()) > 0 else 1.0
    Q = defaultdict(float)
    for src, outs in graph.edges_out.items():
        for e in outs:
            Q[(e.src, e.dst)] = max(1e-6, potential[e.dst] * e.prob)

    accepted = {}
    evals = 0
    t0 = time.perf_counter()

    for round_index in range(params["max_rounds"]):
        new_deposits = []
        for ant_index in range(params["ants"]):
            if evals >= budget:
                break
            node = graph.start
            pn = [node]
            pe = []
            step = 0

            while node not in (graph.success, graph.fail):
                outs = graph.edges_out[node]
                if rng.random() < params["greedy"]:
                    e = max(
                        outs,
                        key=lambda x: (pher[(x.src, x.dst)] ** params["alpha"])
                        * (max(Q[(x.src, x.dst)], 1e-8) ** params["beta"])
                        * (immediate_heuristic(graph, x, mode) ** params["gamma_h"]),
                    )
                else:
                    ws = []
                    for e0 in outs:
                        h = immediate_heuristic(graph, e0, mode)
                        q = max(Q[(e0.src, e0.dst)], 1e-8)
                        extra = 1 + params["pot_w"] * potential[e0.dst]
                        w = (pher[(e0.src, e0.dst)] ** params["alpha"]) * (q ** params["beta"]) * (h ** params["gamma_h"]) * extra
                        if step < 2:
                            w *= 1 + 0.5 * potential[e0.dst] / scale_pot
                        ws.append(max(w, 1e-12))
                    total = sum(ws)
                    r = rng.random() * total
                    c = 0.0
                    e = outs[-1]
                    for e0, w in zip(outs, ws):
                        c += w
                        if c >= r:
                            e = e0
                            break
                pe.append(e)
                pn.append(e.dst)
                node = e.dst
                step += 1

            evals += 1
            is_duplicate = pn[-1] == graph.success and tuple(pn) in accepted
            score_prev = 0.0
            curr_prob = 1.0
            curr_val = 1.0 if mode == "mult" else 0.0
            rewards = []

            for idx, e in enumerate(pe):
                src = graph.nodes[e.src]
                curr_prob *= e.prob
                if src.kind == "regular":
                    if mode == "mult":
                        curr_val *= src.mult_value
                    else:
                        curr_val += src.add_value
                score = curr_prob * curr_val
                delta = score - score_prev
                score_prev = score
                if idx == len(pe) - 1 and e.dst == graph.success:
                    terminal_bonus = params["hit_bonus"]
                elif idx == len(pe) - 1 and e.dst == graph.fail:
                    terminal_bonus = -params["fail_penalty"]
                else:
                    terminal_bonus = 0.0
                duplicate_cost = params["dup_penalty"] if is_duplicate and idx == len(pe) - 1 else 0.0
                rewards.append(params["delta_w"] * delta + terminal_bonus - params["dt_pen"] * e.dt
                               - params["cost_pen"] * e.cost - duplicate_cost)

            for e, r in zip(reversed(pe), reversed(rewards)):
                future = 0.0 if e.dst in (graph.success, graph.fail) else max(Q[(x.src, x.dst)] for x in graph.edges_out[e.dst])
                key = (e.src, e.dst)
                Q[key] = (1 - params["lr"]) * Q[key] + params["lr"] * (r + params["gamma_q"] * future + params["pot_bonus"] * potential[e.dst])

            if pn[-1] == graph.success:
                c = contrib_of(graph, pn, pe, mode)
                sig = tuple(pn)
                if c > 0 and sig not in accepted:
                    accepted[sig] = (pn, pe, c)
                    dep = params["deposit_scale"] * c / max(1, len(pe))
                    new_deposits.append((pe, dep))

            if sum(v[2] for v in accepted.values()) >= threshold:
                break
        for key in list(pher.keys()):
            pher[key] *= (1 - params["evap"])
            if pher[key] < 0.05:
                pher[key] = 0.05
        for path_edges, dep in new_deposits:
            for edge in path_edges:
                pher[(edge.src, edge.dst)] += dep
        if evals >= budget or sum(v[2] for v in accepted.values()) >= threshold:
            break

    runtime_ms = (time.perf_counter() - t0) * 1000
    metrics = compute_metrics_from_paths(graph, accepted, compact_ref, threshold, mode)
    metrics.update({"runtime_ms": runtime_ms, "evals": evals, "method": "QACO"})
    return metrics


def build_benchmark_cache(graphs, top_k=12, threshold_fraction=0.85):
    cache = {}
    for case, g in graphs.items():
        paths = enumerate_paths(g)
        info = {
            "case": case,
            "states": len(g.nodes),
            "edges": sum(len(v) for v in g.edges_out.values()),
            "terminal_paths": len(paths),
            "time_bound": g.time_bound,
            "width": g.width,
            "outdeg": g.outdeg,
        }
        for mode in ("mult", "add"):
            contribs = [path_contribution(g, pn, pe, mode) for pn, pe, _ in paths]
            contribs_sorted = sorted(contribs, reverse=True)
            info[f"exact_{mode}"] = sum(contribs_sorted)
            info[f"ref_{mode}"] = sum(contribs_sorted[:top_k])
            info[f"thr_{mode}"] = threshold_fraction * info[f"ref_{mode}"]
            info[f"topk_{mode}"] = contribs_sorted[:top_k]
        cache[case] = info
    return cache


def run_experiments(output_dir="aeb_experiment_package", n_seeds=12):
    figdir = os.path.join(output_dir, "figures")
    datadir = os.path.join(output_dir, "data")
    os.makedirs(figdir, exist_ok=True)
    os.makedirs(datadir, exist_ok=True)

    graphs = {
        "AEB-S1": generate_aeb_graph("AEB-S1", 12, 2, seed=1),
        "AEB-S2": generate_aeb_graph("AEB-S2", 18, 3, seed=2),
        "AEB-S3": generate_aeb_graph("AEB-S3", 26, 4, seed=3),
        "AEB-S4": generate_aeb_graph("AEB-S4", 34, 5, seed=4),
    }
    budgets = {"AEB-S1": 60, "AEB-S2": 140, "AEB-S3": 260, "AEB-S4": 420}
    cache = build_benchmark_cache(graphs)

    exact_rows = []
    benchmark_rows = []
    exact_reference_rows = []

    for case, g in graphs.items():
        paths = enumerate_paths(g)
        enum_mult = sum(path_contribution(g, pn, pe, "mult") for pn, pe, _ in paths)
        enum_add = sum(path_contribution(g, pn, pe, "add") for pn, pe, _ in paths)
        _, dp_mult, dp_add = dp_mult_add(g)
        exact_rows.append(
            {
                "case": case,
                "dp_terminal_paths": len(paths),
                "enum_terminal_paths": len(paths),
                "mult_error": abs(dp_mult - enum_mult),
                "add_error": abs(dp_add - enum_add),
            }
        )
        benchmark_rows.append(
            {
                "case": case,
                "modules": "sensor acquisition -> fusion -> threat scoring -> braking policy -> actuator allocation -> hydraulic execution -> slip stability control -> recovery/confirmation",
                "stages": len(g.stages),
                "width": g.width,
                "out_degree": g.outdeg,
                "states": len(g.nodes),
                "edges": sum(len(v) for v in g.edges_out.values()),
                "terminal_paths": cache[case]["terminal_paths"],
                "time_bound": g.time_bound,
                "budget": budgets[case],
            }
        )
        exact_reference_rows.append(
            {
                "case": case,
                "exact_mult": cache[case]["exact_mult"],
                "exact_add": cache[case]["exact_add"],
                "compact_ref_mult_top12": cache[case]["ref_mult"],
                "compact_ref_add_top12": cache[case]["ref_add"],
                "threshold_mult_85pct": cache[case]["thr_mult"],
                "threshold_add_85pct": cache[case]["thr_add"],
            }
        )

    rows = []
    for seed in range(1, n_seeds + 1):
        for case, g in graphs.items():
            for mode in ("mult", "add"):
                compact_ref = cache[case][f"ref_{mode}"]
                threshold = cache[case][f"thr_{mode}"]
                rows.append({"seed": seed, "case": case, "mode": mode, **run_aco(g, mode, compact_ref, threshold, budgets[case], seed)})
                rows.append({"seed": seed, "case": case, "mode": mode, **run_ga(g, mode, compact_ref, threshold, budgets[case], seed)})
                rows.append({"seed": seed, "case": case, "mode": mode, **run_qaco(g, mode, compact_ref, threshold, budgets[case], seed)})
                rows.append({"seed": seed, "case": case, "mode": mode, **run_tabu(g, mode, compact_ref, threshold, budgets[case], seed)})

    df = pd.DataFrame(rows)
    overall = df.groupby("method").agg(
        time_ms_mean=("runtime_ms", "mean"),
        time_ms_std=("runtime_ms", "std"),
        ref_cov_mean=("reference_coverage", "mean"),
        ref_cov_std=("reference_coverage", "std"),
        ref_gap_mean=("reference_gap", "mean"),
        ref_gap_std=("reference_gap", "std"),
        compact_mean=("compactness", "mean"),
        compact_std=("compactness", "std"),
        success_mean=("success", "mean"),
        success_std=("success", "std"),
    ).reset_index()

    by_scale = df.groupby(["case", "method"]).agg(
        time_ms_mean=("runtime_ms", "mean"),
        time_ms_std=("runtime_ms", "std"),
        ref_cov_mean=("reference_coverage", "mean"),
        ref_cov_std=("reference_coverage", "std"),
        ref_gap_mean=("reference_gap", "mean"),
        ref_gap_std=("reference_gap", "std"),
        compact_mean=("compactness", "mean"),
        compact_std=("compactness", "std"),
        success_mean=("success", "mean"),
        success_std=("success", "std"),
    ).reset_index()

    by_mode = df.groupby(["mode", "method"]).agg(
        ref_cov_mean=("reference_coverage", "mean"),
        ref_cov_std=("reference_coverage", "std"),
        success_mean=("success", "mean"),
        success_std=("success", "std"),
        compact_mean=("compactness", "mean"),
        compact_std=("compactness", "std"),
    ).reset_index()

    threshold_fracs = [0.75, 0.80, 0.85, 0.90, 0.95, 1.00]
    threshold_rows = []
    g = graphs["AEB-S4"]
    compact_ref = cache["AEB-S4"]["ref_add"]
    for frac in threshold_fracs:
        thr = compact_ref * frac
        for seed in range(1, n_seeds + 1):
            threshold_rows.append({"seed": seed, "case": "AEB-S4", "mode": "add", "threshold_fraction": frac, **run_aco(g, "add", compact_ref, thr, budgets["AEB-S4"], seed)})
            threshold_rows.append({"seed": seed, "case": "AEB-S4", "mode": "add", "threshold_fraction": frac, **run_ga(g, "add", compact_ref, thr, budgets["AEB-S4"], seed)})
            threshold_rows.append({"seed": seed, "case": "AEB-S4", "mode": "add", "threshold_fraction": frac, **run_qaco(g, "add", compact_ref, thr, budgets["AEB-S4"], seed)})
            threshold_rows.append({"seed": seed, "case": "AEB-S4", "mode": "add", "threshold_fraction": frac, **run_tabu(g, "add", compact_ref, thr, budgets["AEB-S4"], seed)})

    threshold_df = pd.DataFrame(threshold_rows)
    threshold_agg = threshold_df.groupby(["threshold_fraction", "method"]).agg(
        time_ms_mean=("runtime_ms", "mean"),
        time_ms_std=("runtime_ms", "std"),
        ref_cov_mean=("reference_coverage", "mean"),
        ref_cov_std=("reference_coverage", "std"),
        compact_mean=("compactness", "mean"),
        compact_std=("compactness", "std"),
        success_mean=("success", "mean"),
        success_std=("success", "std"),
    ).reset_index()

    pd.DataFrame(benchmark_rows).to_csv(os.path.join(datadir, "benchmark_cases.csv"), index=False)
    pd.DataFrame(exact_reference_rows).to_csv(os.path.join(datadir, "exact_reference_values.csv"), index=False)
    pd.DataFrame(exact_rows).to_csv(os.path.join(datadir, "exact_verification.csv"), index=False)
    df.to_csv(os.path.join(datadir, "run_results.csv"), index=False)
    overall.to_csv(os.path.join(datadir, "overall_results.csv"), index=False)
    by_scale.to_csv(os.path.join(datadir, "by_scale_results.csv"), index=False)
    by_mode.to_csv(os.path.join(datadir, "by_mode_results.csv"), index=False)
    threshold_df.to_csv(os.path.join(datadir, "threshold_sensitivity_runs.csv"), index=False)
    threshold_agg.to_csv(os.path.join(datadir, "threshold_sensitivity_summary.csv"), index=False)

    if plt is None:
        print("matplotlib is not installed; numerical CSV files were written and figure generation was skipped.")
        return

    plt.rcParams.update({
        "figure.dpi": 180,
        "savefig.dpi": 180,
        "font.size": 10,
        "axes.titlesize": 11,
        "axes.labelsize": 10,
        "legend.fontsize": 9,
        "xtick.labelsize": 9,
        "ytick.labelsize": 9,
    })

    method_order = ["QACO", "ACO", "GA", "Tabu"]

    def save_bar(df_metric, mean_col, std_col, ylabel, filename):
        d = df_metric.set_index("method").loc[method_order].reset_index()
        fig, ax = plt.subplots(figsize=(5.6, 3.6))
        ax.bar(d["method"], d[mean_col], yerr=d[std_col], capsize=4)
        ax.set_ylabel(ylabel)
        ax.set_xlabel("Method")
        ax.grid(axis="y", alpha=0.25)
        plt.tight_layout()
        fig.savefig(os.path.join(figdir, filename), bbox_inches="tight")
        plt.close(fig)

    def save_clean_grouped_bars(df_metric, xcol, mean_col, ylabel, filename, categories, labels, ylim=None, decimals=3):
        fig, ax = plt.subplots(figsize=(6.6, 4.0))
        x = np.arange(len(categories))
        width = 0.18
        offsets = np.linspace(-1.5 * width, 1.5 * width, len(method_order))
        for off, m in zip(offsets, method_order):
            sub = df_metric[df_metric["method"] == m].set_index(xcol).reindex(categories)
            vals = sub[mean_col].to_numpy()
            bars = ax.bar(x + off, vals, width=width, label=m)
            pad = (ylim[1] - ylim[0]) * 0.012 if ylim is not None else max(vals) * 0.03
            for b, v in zip(bars, vals):
                ax.text(b.get_x() + b.get_width() / 2, v + pad, f"{v:.{decimals}f}",
                        ha="center", va="bottom", fontsize=7, rotation=90)
        ax.set_xticks(x)
        ax.set_xticklabels(labels)
        ax.set_ylabel(ylabel)
        ax.grid(axis="y", alpha=0.25)
        if ylim is not None:
            ax.set_ylim(*ylim)
        ax.legend(frameon=False, ncol=4, loc="upper center", bbox_to_anchor=(0.5, 1.16))
        plt.tight_layout()
        fig.savefig(os.path.join(figdir, filename), bbox_inches="tight")
        plt.close(fig)

    def save_threshold_line(df_metric, xcol, ycol, ylabel, filename, std_col=None, xorder=None, ylim=None):
        fig, ax = plt.subplots(figsize=(6.2, 3.9))
        markers = {"QACO": "o", "ACO": "s", "GA": "^", "Tabu": "D"}
        for m in method_order:
            d = df_metric[df_metric["method"] == m].copy()
            if xorder is not None:
                d[xcol] = pd.Categorical(d[xcol], categories=xorder, ordered=True)
                d = d.sort_values(xcol)
            x = d[xcol].astype(float).to_numpy()
            y = d[ycol].to_numpy()
            ax.plot(x, y, marker=markers[m], label=m)
            if std_col is not None:
                e = d[std_col].fillna(0).to_numpy()
                ax.fill_between(x, y - e, y + e, alpha=0.12)
        ax.set_xlabel("Threshold fraction")
        ax.set_ylabel(ylabel)
        ax.grid(axis="y", alpha=0.25)
        if ylim is not None:
            ax.set_ylim(*ylim)
        ax.legend(frameon=False, ncol=2)
        plt.tight_layout()
        fig.savefig(os.path.join(figdir, filename), bbox_inches="tight")
        plt.close(fig)

    save_bar(overall, "ref_cov_mean", "ref_cov_std", "Reference coverage", "overall_reference_coverage.png")
    save_bar(overall, "time_ms_mean", "time_ms_std", "Runtime (ms)", "overall_runtime_ms.png")
    save_bar(overall, "compact_mean", "compact_std", "Compactness", "overall_compactness.png")
    save_bar(overall, "success_mean", "success_std", "Success rate", "overall_success_rate.png")

    save_clean_grouped_bars(by_scale, "case", "ref_cov_mean", "Mean reference coverage", "reference_coverage_by_scale.png",
                            categories=["AEB-S1", "AEB-S2", "AEB-S3", "AEB-S4"], labels=["AEB-S1", "AEB-S2", "AEB-S3", "AEB-S4"],
                            ylim=(0.55, 1.12), decimals=3)
    save_clean_grouped_bars(by_scale, "case", "time_ms_mean", "Mean runtime (ms)", "runtime_by_scale.png",
                            categories=["AEB-S1", "AEB-S2", "AEB-S3", "AEB-S4"], labels=["AEB-S1", "AEB-S2", "AEB-S3", "AEB-S4"],
                            ylim=(0, 21), decimals=2)
    save_clean_grouped_bars(by_scale, "case", "compact_mean", "Mean compactness", "compactness_by_scale.png",
                            categories=["AEB-S1", "AEB-S2", "AEB-S3", "AEB-S4"], labels=["AEB-S1", "AEB-S2", "AEB-S3", "AEB-S4"],
                            ylim=(0, 0.52), decimals=3)
    save_clean_grouped_bars(by_scale, "case", "success_mean", "Mean success rate", "success_by_scale.png",
                            categories=["AEB-S1", "AEB-S2", "AEB-S3", "AEB-S4"], labels=["AEB-S1", "AEB-S2", "AEB-S3", "AEB-S4"],
                            ylim=(0, 1.08), decimals=3)
    save_clean_grouped_bars(by_mode, "mode", "ref_cov_mean", "Mean reference coverage", "reference_coverage_by_mode.png",
                            categories=["add", "mult"], labels=["Additive", "Multiplicative"],
                            ylim=(0.74, 0.90), decimals=3)
    save_clean_grouped_bars(by_mode, "mode", "success_mean", "Mean success rate", "success_by_mode.png",
                            categories=["add", "mult"], labels=["Additive", "Multiplicative"],
                            ylim=(0, 1.08), decimals=3)

    save_threshold_line(threshold_agg, "threshold_fraction", "ref_cov_mean", "Reference coverage", "threshold_sensitivity_reference_coverage.png", std_col="ref_cov_std", xorder=threshold_fracs)
    save_threshold_line(threshold_agg, "threshold_fraction", "time_ms_mean", "Runtime (ms)", "threshold_sensitivity_runtime.png", std_col="time_ms_std", xorder=threshold_fracs)
    save_threshold_line(threshold_agg, "threshold_fraction", "compact_mean", "Compactness", "threshold_sensitivity_compactness.png", std_col="compact_std", xorder=threshold_fracs)


if __name__ == "__main__":
    run_experiments()
