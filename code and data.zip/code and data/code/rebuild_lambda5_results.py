"""Rebuild the QACO records and manuscript summaries with lambda_5 = 0.01.

Run from the repository root: python code/rebuild_lambda5_results.py
Other methods' saved observations remain as recorded. Wall-clock runtime varies by run.
"""
from __future__ import annotations

import math
from pathlib import Path

import pandas as pd

import aeb_trace_experiments as exp
import revision_analysis


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
TABLES = ROOT / "tables"
SPECS = [
    ("AEB-S1", 12, 2, 1, 60),
    ("AEB-S2", 18, 3, 2, 140),
    ("AEB-S3", 26, 4, 3, 260),
    ("AEB-S4", 34, 5, 4, 420),
]
GRAPHS = {case: exp.generate_aeb_graph(case, width, degree, seed=graph_seed)
          for case, width, degree, graph_seed, _ in SPECS}
CACHE = exp.build_benchmark_cache(GRAPHS)
BUDGETS = {case: budget for case, _, _, _, budget in SPECS}
METRICS = ["exact_ratio", "compact_ratio", "compactness", "success", "runtime_ms"]
TCRIT = {96: 1.9852510035091888, 48: 2.0117405137297655,
         24: 2.0686576104190406}


def write_results(batched: pd.DataFrame) -> pd.DataFrame:
    runs = pd.read_csv(DATA / "run_results_with_ratios.csv")
    assert len(runs) == 384 and len(runs[runs.method == "QACO"]) == 96
    fields = ["returned_value", "reference_coverage", "reference_gap",
              "compactness", "success", "accepted_paths", "runtime_ms", "evals"]
    lookup = batched.set_index(["case", "mode", "seed"])
    for idx, row in runs[runs.method == "QACO"].iterrows():
        case, mode, seed = row["case"], row["mode"], int(row["seed"])
        result = lookup.loc[(case, mode, seed)]
        for field in fields:
            runs.at[idx, field] = result[field]
        runs.at[idx, "exact_ratio"] = result["returned_value"] / CACHE[case][f"exact_{mode}"]
        runs.at[idx, "compact_ratio"] = result["reference_coverage"]
    runs.to_csv(DATA / "run_results_with_ratios.csv", index=False)
    runs[["seed", "case", "mode", *fields, "method"]].to_csv(DATA / "run_results.csv", index=False)
    return runs


def summarize(runs: pd.DataFrame, keys: list[str]) -> pd.DataFrame:
    rows = []
    for group_key, group in runs.groupby(keys, sort=True):
        if not isinstance(group_key, tuple):
            group_key = (group_key,)
        n = len(group)
        item = dict(zip(keys, group_key))
        item["n"] = n
        for metric in METRICS:
            mean = float(group[metric].mean())
            std = float(group[metric].std(ddof=1))
            half = TCRIT[n] * std / math.sqrt(n)
            item[f"{metric}_mean"] = mean
            item[f"{metric}_std"] = std
            item[f"{metric}_ci_low"] = mean - half
            item[f"{metric}_ci_high"] = mean + half
        rows.append(item)
    return pd.DataFrame(rows)


def write_summaries(runs: pd.DataFrame) -> None:
    groups = [(["method"], "overall_results_with_ci.csv"),
              (["case", "method"], "by_scale_results_with_ci.csv"),
              (["mode", "method"], "by_mode_results_with_ci.csv")]
    for keys, name in groups:
        summarize(runs, keys).to_csv(DATA / name, index=False)

    overall = pd.read_csv(DATA / "overall_results_with_ci.csv")
    mean_lines, ci_lines = [], []
    for _, row in overall.iterrows():
        mean_fields = [f"{row[f'{m}_mean']:.4f} $\\pm$ {row[f'{m}_std']:.4f}" for m in METRICS]
        ci_fields = [f"[{row[f'{m}_ci_low']:.4f}, {row[f'{m}_ci_high']:.4f}]" for m in METRICS]
        mean_lines.append(" & ".join([row["method"], *mean_fields]) + r" \\")
        ci_lines.append(" & ".join([row["method"], *ci_fields]) + r" \\")
    (TABLES / "overall_mean_std_rows.tex").write_text("\n".join(mean_lines) + "\n", encoding="utf-8")
    (TABLES / "overall_ci_rows.tex").write_text("\n".join(ci_lines) + "\n", encoding="utf-8")


def write_batched() -> pd.DataFrame:
    prior = pd.read_csv(DATA / "qaco_batched_reproduction_runs.csv")
    assert len(prior) == 96
    for idx, row in prior.iterrows():
        case, mode, seed = row["case"], row["mode"], int(row["seed"])
        result = exp.run_qaco(GRAPHS[case], mode,
                              CACHE[case][f"ref_{mode}"], CACHE[case][f"thr_{mode}"],
                              BUDGETS[case], seed)
        for field in ("returned_value", "reference_coverage", "reference_gap",
                      "compactness", "success", "accepted_paths", "runtime_ms", "evals"):
            prior.at[idx, field] = result[field]
        prior.at[idx, "exact_ratio"] = result["returned_value"] / CACHE[case][f"exact_{mode}"]
        prior.at[idx, "compact_ratio"] = result["reference_coverage"]
    prior.to_csv(DATA / "qaco_batched_reproduction_runs.csv", index=False)
    prior[METRICS].agg(["mean", "std"]).T.to_csv(DATA / "qaco_batched_reproduction_summary.csv")
    return prior


def write_sensitivity() -> None:
    raw, summary = revision_analysis.run_parameter_sensitivity(n_seeds=12)
    for name in ("qaco_parameter_sensitivity_runs.csv",
                 "qaco_parameter_sensitivity_runs_batched.csv"):
        raw.to_csv(DATA / name, index=False)
    for name in ("qaco_parameter_sensitivity_summary.csv",
                 "qaco_parameter_sensitivity_summary_batched.csv",
                 "qaco_sensitivity_table_source.csv"):
        summary.to_csv(DATA / name, index=False)


def write_thresholds() -> None:
    summary = pd.read_csv(DATA / "threshold_sensitivity_summary.csv")
    graph = GRAPHS["AEB-S4"]
    ref = CACHE["AEB-S4"]["ref_add"]
    rows = []
    for fraction in sorted(summary.threshold_fraction.unique()):
        for seed in range(1, 13):
            result = exp.run_qaco(graph, "add", ref, ref * fraction, 420, seed)
            rows.append({"threshold_fraction": fraction, "seed": seed, **result})
    raw = pd.DataFrame(rows)
    raw["exact_ratio"] = raw["returned_value"] / CACHE["AEB-S4"]["exact_add"]
    raw.to_csv(DATA / "threshold_sensitivity_qaco_runs.csv", index=False)
    for fraction, group in raw.groupby("threshold_fraction"):
        target = (summary.threshold_fraction == fraction) & (summary.method == "QACO")
        assert target.sum() == 1
        for source, dest in (("runtime_ms", "time_ms"),
                             ("reference_coverage", "ref_cov"),
                             ("compactness", "compact"), ("success", "success")):
            summary.loc[target, f"{dest}_mean"] = group[source].mean()
            summary.loc[target, f"{dest}_std"] = group[source].std(ddof=1)
    summary.to_csv(DATA / "threshold_sensitivity_summary.csv", index=False)
    factor = ref / CACHE["AEB-S4"]["exact_add"]
    source = summary.copy()
    source["exact_ratio_mean"] = source["ref_cov_mean"] * factor
    source["exact_ratio_std"] = source["ref_cov_std"] * factor
    source.to_csv(DATA / "figure12_13_source.csv", index=False)


if __name__ == "__main__":
    assert exp.run_qaco.__code__.co_consts
    write_summaries(write_results(write_batched()))
    write_sensitivity()
    write_thresholds()
    print("Updated 96 main QACO runs, 96 batched reruns, 108 sensitivity runs, and 72 threshold runs.")
